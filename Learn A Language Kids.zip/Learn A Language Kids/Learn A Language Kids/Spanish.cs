﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Learn_A_Language_Kids
{
    public partial class Frm4 : Form
    {
        public Frm4()
        {
            InitializeComponent();
        }
    }
}
